function leDados() {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse(strDados);
    } else {
        objDados = {
            noticias: []
        };
    }

    return objDados;
}

function salvaDados(dados) {
    localStorage.setItem('db', JSON.stringify(dados));
}

function incluirNoticia() {
    let objDados = leDados();

    let strId = document.querySelector('.id').value;
    let strCategoria = document.querySelector('.categoria').value;
    let strTitulo = document.querySelector('.Titulo').value;
    let strSite = document.querySelector('.Site').value;
    let strDescricao = document.querySelector('.descricao').value;

    let novaNoticia = {
        id: strId,
        categoria: strCategoria,
        titulo: strTitulo,
        site: strSite,
        descricao: strDescricao
    };

    objDados.noticias.push(novaNoticia);

    salvaDados(objDados);

    imprimeNoticias();
}

function imprimeNoticias() {
    let table = document.querySelector('.news-table');
    let objDados = leDados();
    let strHtml = '';

    for (let i = 0; i < objDados.noticias.length; i++) {
        strHtml += `
            <tr>
                <td>${objDados.noticias[i].id}</td>
                <td>${objDados.noticias[i].categoria}</td>
                <td>${objDados.noticias[i].titulo}</td>
                <td>${objDados.noticias[i].site}</td>
                <td>${objDados.noticias[i].descricao}</td>
            </tr>
        `;
    }

    table.innerHTML = strHtml;
}

document.querySelector('.button1').addEventListener('click', incluirNoticia);
document.querySelector('.button4').addEventListener('click', () => {
    document.querySelector('.id').value = '';
    document.querySelector('.categoria').value = '';
    document.querySelector('.Titulo').value = '';
    document.querySelector('.Site').value = '';
    document.querySelector('.descricao').value = '';
});

document.querySelector('.button3').addEventListener('click', () => {
    // Obtenha o ID do item a ser excluído (pode ser obtido de várias maneiras, 
    // aqui vou assumir que você tem uma variável com o ID)
    let idParaExcluir = document.querySelector('.id').value;

    // Obtenha os dados armazenados
    let objDados = leDados();

    // Encontre o índice do item na lista de notícias com base no ID
    let index = objDados.noticias.findIndex(noticia => noticia.id === idParaExcluir);

    // Se o item foi encontrado, remova-o da lista
    if (index !== -1) {
        objDados.noticias.splice(index, 1);

        // Salve os dados atualizados no armazenamento local
        salvaDados(objDados);

        // Atualize a exibição da tabela
        imprimeNoticias();
    } else {
        // Caso o item com o ID especificado não seja encontrado
        console.log("Item não encontrado para exclusão.");
    }
});

function imprimeNoticias() {
    let table = document.querySelector('.news-table');
    let objDados = leDados();
    let tableBody = table.querySelector('tbody') || table.createTBody(); // Se o tbody não existir, crie um
    let strHtml = '';

    // Limpe o conteúdo existente da tabela
    tableBody.innerHTML = '';

    for (let i = 0; i < objDados.noticias.length; i++) {
        // Crie uma nova linha para cada notícia
        let newRow = tableBody.insertRow();

        // Insira as células na nova linha
        let idCell = newRow.insertCell();
        let categoriaCell = newRow.insertCell();
        let tituloCell = newRow.insertCell();
        let siteCell = newRow.insertCell();
        let descricaoCell = newRow.insertCell();

        // Preencha as células com os dados da notícia
        idCell.textContent = objDados.noticias[i].id;
        categoriaCell.textContent = objDados.noticias[i].categoria;
        tituloCell.textContent = objDados.noticias[i].titulo;
        siteCell.textContent = objDados.noticias[i].site;
        descricaoCell.textContent = objDados.noticias[i].descricao;
    }
}

