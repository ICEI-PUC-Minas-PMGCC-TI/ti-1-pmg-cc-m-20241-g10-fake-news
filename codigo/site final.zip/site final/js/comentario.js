document.addEventListener('DOMContentLoaded', (event) => {
    const emojis = document.querySelectorAll('.emoji');
    let selectedRating = '';

    emojis.forEach(emoji => {
        emoji.addEventListener('mouseover', () => {
            emoji.style.transform = 'rotate(20deg) scale(1.2)';
            emoji.style.transition = 'transform 0.3s';
        });

        emoji.addEventListener('mouseout', () => {
            emoji.style.transform = 'rotate(0deg) scale(1)';
            emoji.style.transition = 'transform 0.3s';
        });

        emoji.addEventListener('click', () => {
            selectedRating = emoji.textContent;
        });
    });

    const commentForm = document.getElementById('comment-form');
    const commentInput = document.getElementById('comment-input');
    const commentsList = document.getElementById('comments-list');

    commentForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const commentText = commentInput.value.trim();

        if (commentText !== '' && selectedRating !== '') {
            const commentDiv = document.createElement('div');
            commentDiv.className = 'comment';

            const ratingSpan = document.createElement('span');
            ratingSpan.textContent = selectedRating + ' ';
            ratingSpan.style.fontSize = '1.5rem';

            const commentSpan = document.createElement('span');
            commentSpan.textContent = commentText;

            commentDiv.appendChild(ratingSpan);
            commentDiv.appendChild(commentSpan);

            commentsList.appendChild(commentDiv);
            commentInput.value = '';
            selectedRating = '';
        } else {
            alert('Por favor, selecione uma avaliação e escreva um comentário.');
        }
    });
});
