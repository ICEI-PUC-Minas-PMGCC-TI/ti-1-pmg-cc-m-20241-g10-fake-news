function searchTopic(event) {
  event.preventDefault(); // Prevent the form from submitting in the traditional way
  const query = document.getElementById('searchInput').value.toLowerCase();
  let url;

  switch(query) {
      case 'saúde e medicina':
      case 'saude e medicina':
      case 'saúde':
      case 'saude':
          url = 'saude.html';
          break;
      case 'política':
      case 'politica':
          url = 'politica.html';
          break;
      case 'educação':
      case 'educacao':
          url = 'educacao.html';
          break;
      case 'ciência e tecnologia':
      case 'ciencia e tecnologia':
      case 'ciência':
      case 'ciencia':
          url = 'ciencia.html';
          break;
      case 'economia':
          url = 'economia.html';
          break;
      default:
          alert('Tópico não encontrado. Tente: Saúde e Medicina, Política, Educação, Ciência e Tecnologia, Economia.');
          return;
  }

  window.open(url, '_blank');
}

