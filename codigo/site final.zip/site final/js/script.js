document.addEventListener("DOMContentLoaded", function () {

    var gallerySection = document.createElement("section");
    gallerySection.className = "my-gallery";


    var titleDiv = document.createElement("div");
    titleDiv.className = "titulo";
    var titleParagraph = document.createElement("p");
    titleParagraph.textContent = "Sites Confiáveis e Para Verificação";
    titleDiv.appendChild(titleParagraph);


    gallerySection.appendChild(titleDiv);


    var galleryDiv = document.createElement("div");
    galleryDiv.className = "galeria";


    var sites = [
        {
            url: "https://www.e-farsas.com",
            imgSrc: "/trabalho-html-2.html/assets/E-Farsas.png",
            alt: "E-Farsas",
            description: "E-Farsas: Um dos sites mais antigos do Brasil focado em desmentir Fake News"
        },
        {
            url: "https://www.estadao.com.br/estadao-verifica/",
            imgSrc: "/trabalho-html-2.html/assets/Estadão.png",
            alt: "Estadão",
            description: "Estadão Verifica: Área do já famoso G1 voltado para desmentir notícias falsas"
        },
        {
            url: "https://nilc-fakenews.herokuapp.com",
            imgSrc: "/trabalho-html-2.html/assets/FaceCheck.png",
            alt: "FakeCheck",
            description: "FakeCheck: Famoso site onde se pesquisa Fake News pelo título"
        },
        {
            url: "https://g1.globo.com/fato-ou-fake",
            imgSrc: "/trabalho-html-2.html/assets/Fato ou Fake.png",
            alt: "Fato ou Fake",
            description: "Fato ou Fake: Área do já famoso G1 voltado para desmentir notícias falsas"
        },
        {
            url: "https://lupa.uol.com.br/?utm_source=googleads&utm_medium=searchads&utm_campaign=institucional&gad_source=1&gclid=CjwKCAjw65-zBhBkEiwAjrqRMKLFnBtiUt7S_24WeMwUxE2O_BVPx4uOCI9qb3i3RyUFaFIXxgvG9xoCRqMQAvD_BwE",
            imgSrc: "/trabalho-html-2.html/assets/Lupa.png",
            alt: "Lupa",
            description: "Lupa: Área do já famoso UOL voltado para desmentir notícias falsas"
        },
        {
            url: "https://apublica.org",
            imgSrc: "/trabalho-html-2.html/assets/Publica.png",
            alt: "Publica",
            description: "Publica: Revista pública, uma ótima fonte de notícias"
        }
    ];


    sites.forEach(function (site) {
        var singleGalleryDiv = document.createElement("div");
        singleGalleryDiv.className = "single-galeria";

        var anchor = document.createElement("a");
        anchor.href = site.url;

        var img = document.createElement("img");
        img.src = site.imgSrc;
        img.alt = site.alt;

        anchor.appendChild(img);
        singleGalleryDiv.appendChild(anchor);

        var infoDiv = document.createElement("div");
        infoDiv.className = "info";

        var infoParagraph = document.createElement("p");
        infoParagraph.textContent = site.description;

        infoDiv.appendChild(infoParagraph);
        singleGalleryDiv.appendChild(infoDiv);

        galleryDiv.appendChild(singleGalleryDiv);
    });

    gallerySection.appendChild(galleryDiv);
    document.body.appendChild(gallerySection);
});
